* Secure the download of the encrypted file behind a challenge/response
