# © 2021 Florian Kantelberg - initOS GmbH
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    test_controller,
    test_log,
    test_rights,
    test_user,
    test_vault,
    test_widgets,
)
